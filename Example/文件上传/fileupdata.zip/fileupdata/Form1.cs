﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace fileupdata
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Weave.TCPClient.P2Pclient pclient = new Weave.TCPClient.P2Pclient(false);
        List<String> listfile = new List<string>();
        List<string> filelist = new List<string>();
        List<string> filelisttrsa = new List<string>();
        
        // string uri = "", username = "", password = "", fileurl = "", savefileurl = "";

        //ftpfile ftp;


        private void Form1_Load(object sender, EventArgs e)
        {

            
            csdata cs = new csdata { filename = "test0020.zip", filetype = "filepath" };
            Class1 c = new Class1();
            c.addtext += C_addtext;
            c.stat(cs);


        }









        private void C_addtext(string text)
        {
            if (Text.Contains("已上传"))
            {
                listBox1.Invoke(new EventHandler(delegate { listBox1.Items.Clear(); }));
            }

            listBox1.Invoke(new EventHandler(delegate { listBox1.Items.Insert(0, text); }));
        }


 



         



    }

    class filestream
    {
        int index;
        int len;
        String filename;
        long maxlen;
        string filetype;
        public int Index
        {
            get
            {
                return index;
            }

            set
            {
                index = value;
            }
        }

        public int Len
        {
            get
            {
                return len;
            }

            set
            {
                len = value;
            }
        }

        public string Filename
        {
            get
            {
                return filename;
            }

            set
            {
                filename = value;
            }
        }

        public byte[] Stream
        {
            get
            {
                return stream;
            }

            set
            {
                stream = value;
            }
        }

        public long Maxlen
        {
            get
            {
                return maxlen;
            }

            set
            {
                maxlen = value;
            }
        }

        public string Filetype
        {
            get
            {
                return filetype;
            }

            set
            {
                filetype = value;
            }
        }

        byte[] stream;
    }
}
